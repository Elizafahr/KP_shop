//Вывод товаров
$("document").ready(function () {
  loadItems();
});

function loadItems() {
  $.getJSON("special.json", function (data) {
    console.log(data);
    let out = "";
    for (let key in data) {
      out += ' <div class="card"  >  ';
      out +=
        '<div class="image-card"> <img  class="card-img-top" src="' +
        data[key].image +
        '"> </div>';
      out +=
        ' <div class="card-body  "> ' +
        '  <div class="d-flex align-items-center gap-2"> ' +
        ' <h5 class="card-title blue">' +
        data[key]["cost"] +
        "₽ </h5> ";
      out +=
        ' <h5 class="card-title  small ligth stroked lastPrice">' +
        data[key]["costLast"] +
        "₽ </h5></div>";
      out += '<p class="card-text">' + data[key]["name"] + "</p>";

      out += "<a href='#' class='btn btn-primary'>Выбрать</a>";
      out += "</div>";
      out += "</div>";
    }
    $("#items").html(out);
  });
}

//слайдер товаров - рекомендуемые
let appendNumber = 600;
let prependNumber = 1;

const swiperEl = document.querySelector("swiper-container");

Object.assign(swiperEl, {
  slidesPerView: 4,
  centeredSlides: false,
  spaceBetween: 10,

  navigation: true,
});

swiperEl.initialize();

const swiper = swiperEl.swiper;
