const products = {
  1: {
    name: "Городской велосипед PULSE диаметр 27,5”",
    cost: 100,
    costLast: 500,
    description: "Рождественский колокольчик",
    image: "/assets/img/png/scooter/scooter-06.png",
  },
  2: {
    name: "Горный велосипед KMS диаметр 26”",
    cost: 4400,
    costLast: 500,
    description: "Шапка Санты Клауса",
    image: "/assets/img/png/scooter/scooter-02.png",
  },
  3: {
    name: "Самокат трюковой KMS TRICK, дека 48 см",
    cost: 5422,
    costLast: 500,
    description: "Рождественские подарки",
    image: "/assets/img/png/scooter/scooter-02.png",
  },
  4: {
    name: "Городской велосипед PULSE диаметр 27,5”",
    cost: 4500,
    costLast: 500,
    description: "Рождественский колокольчик",
    image: "/assets/img/png/scooter/scooter-03.png",
  },
  5: {
    name: "Городской велосипед PULSE диаметр 27,5”",
    cost: 2000,
    costLast: 500,
    description: "Шапка Санты Клауса",
    image: "/assets/img/png/scooter/scooter-04.png",
  },
  6: {
    name: "Горный велосипед KMS диаметр 26”",
    cost: 26000,
    costLast: 500,
    description: "Рождественские подарки",
    image: "/assets/img/png/scooter/scooter-05.png",
  },
};
