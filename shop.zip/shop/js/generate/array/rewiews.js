const rewiews = {
    "1": {
      "name": "Иван Иванов",
      "textRewiew": "Отличный сервис, всем рекомендую!",
      "image": "assets/img/png/userImage.png"
    },
    "2": {
      "name": "Мария Смирнова",
      "textRewiew": "Очень довольна качеством услуг, обязательно вернусь снова!",
      "image": "assets/img/png/userImageWomen.png"
    },
    "3": {
      "name": "Алексей Петров",
      "textRewiew": "Превосходное обслуживание, спасибо большое!",
      "image": "assets/img/png/userImage.png"
    },
    "4": {
      "name": "Елена Козлова",
      "textRewiew": "Замечательный опыт, обязательно рекомендую этот сервис!",
      "image": "assets/img/png/userImageWomen.png"
    },
    "5": {
      "name": "Дмитрий Николаев",
      "textRewiew": "Отличное соотношение цены и качества, всем советую!",
      "image": "assets/img/png/userImage.png"
    },
    "6": {
      "name": "Татьяна Соколова",
      "textRewiew": "Профессиональный подход, всегда радует качество услуг!",
      "image": "assets/img/png/userImageWomen.png"
    },
    "7": {
      "name": "Павел Иванов",
      "textRewiew": "Очень понравилось, обязательно приду снова!",
      "image": "assets/img/png/userImage.png"
    },
    "8": {
      "name": "Ольга Морозова",
      "textRewiew": "Отличный сервис, всегда радуете своим качеством.",
      "image": "assets/img/png/userImageWomen.png"
    },
    "9": {
      "name": "Сергей Волков",
      "textRewiew": "Спасибо за прекрасное обслуживание, все супер!",
      "image": "assets/img/png/userImage.png"
    },
    "10": {
      "name": "Анна Кузнецова",
      "textRewiew": "Всегда остаюсь довольной, когда пользуюсь вашими услугами!",
      "image": "assets/img/png/userImageWomen.png"
    },
    "11": {
      "name": "Ирина Алексеева",
      "textRewiew": "Отличный сервис, надежный и профессиональный!",
      "image": "assets/img/png/userImageWomen.png"
    },
    "12": {
      "name": "Константин Степанов",
      "textRewiew": "Самый лучший сервис, с нетерпением буду ждать новых акций!",
      "image": "assets/img/png/userImage.png"
    },
    "13": {
      "name": "Евгения Новикова",
      "textRewiew": "Благодарю за отличное обслуживание, обязательно порекомендую друзьям!",
      "image": "assets/img/png/userImageWomen.png"
    },
    "14": {
      "name": "Александр Краснов",
      "textRewiew": "Очень приятное обслуживание, спасибо вам!",
      "image": "assets/img/png/userImage.png"
    },
    "15": {
      "name": "Наталья Беляева",
      "textRewiew": "Постоянно пользуюсь вашими услугами, всегда на высоте!",
      "image": "assets/img/png/userImageWomen.png"
    }
  }
  