//Вывод товаров и отзывов
$("document").ready(function () {
  outRewiews();
  outSpecial();
  outGoods();
});
